import subprocess
import time
import re
import sys

print("Connecting to Pinggy over port 443...")
cmd = ["ssh", "-p", "443", "-o", "StrictHostKeyChecking=no", "-o", "ServerAliveInterval=30", "-R0:localhost:3000", "a.pinggy.io"]

proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)

url_found = None
start_time = time.time()
while time.time() - start_time < 20:
    line = proc.stdout.readline()
    if line:
        print(line.strip())
        match = re.search(r'https://[a-zA-Z0-9-]+\.a\.pinggy\.link', line)
        if match:
            url_found = match.group(0)
            print("=" * 60)
            print("PINGGY PUBLIC URL FOUND:", url_found)
            print("=" * 60)
            with open("pinggy_url.txt", "w") as f:
                f.write(url_found)
            break
    time.sleep(0.1)

if not url_found:
    print("Could not find Pinggy URL within 20s.")
else:
    # Keep process running
    proc.wait()
